chmod +x pgen
sudo cp pgen /usr/local/bin/
