[INSTTALLATION GUIDE]

    $ chmod +x install.sh
    $ ./install.sh

[HOW TO USE]

    $ pgen

or

    $ pgen -h

or

    $ pgen --help for usage